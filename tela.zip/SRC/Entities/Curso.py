from DB.Conexao import conectar
class Curso:
    def __init__(self, idcurso = None ,nome = None,ch = None):
        self.idcurso = idcurso
        self.nome = nome
        self.ch = ch
        
    def incluir(self):
        con = conectar()
        cursor = con.cursor()
        sql = f'insert into curso (nome,ch) values ("{self.nome}",{self.ch})'
        cursor.execute(sql)
        con.commit()
        con.close()
    
    def buscar(self):
        con = conectar()
        cursor = con.cursor()
        sql = 'select * from curso'
        cursor.execute(sql)
        resultado = cursor.fetchall()
        return resultado
    
    def test(self):
        print("oi")