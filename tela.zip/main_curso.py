import sys
from PySide6 import QtWidgets
from tela.ui_Curso import Ui_Form
from SRC.Entities.Curso import Curso

class Main(QtWidgets.QMainWindow, Ui_Form):
    def __init__(self):
        super(Main,self).__init__()
        self.setupUi(self)
        self.btnInserir.clicked.connect(self.incluir)
    
    def incluir(self):
        try:
            nome = self.edtNome.text()
            ch = int(self.ednCH.text())
            curso = Curso(0,nome,ch)
            curso.incluir()
            print(curso.buscar())
            print("incluido com sucesso")
        except Exception as erro:
            print("Erro ao Inserir")
            print(erro)
        
app = QtWidgets.QApplication(sys.argv)

window = Main()
window.show()
app.exec()