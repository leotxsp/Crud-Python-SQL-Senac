

INSERT INTO curso (nome,ch) value ("informatica",40)